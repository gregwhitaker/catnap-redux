import org.jetbrains.dokka.gradle.tasks.DokkaGeneratePublicationTask
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("catnap.java-library")
    id("org.jetbrains.kotlin.jvm")
    id("org.jetbrains.dokka")
}

// Maven's documentation classifier may contain Dokka HTML; Java's javadoc task cannot read Kotlin.
tasks.named<Jar>("javadocJar") {
    from(
        tasks.named<DokkaGeneratePublicationTask>("dokkaGeneratePublicationHtml").flatMap {
            it.outputDirectory
        }
    )
}

dokka { dokkaPublications.configureEach { offlineMode.set(true) } }

kotlin {
    jvmToolchain(17)
    compilerOptions { jvmTarget = JvmTarget.JVM_17 }
}

val catalog = extensions.findByType<VersionCatalogsExtension>()?.find("libs")?.orElse(null)

if (catalog != null)
    spotless {
        kotlin {
            target("src/**/*.kt")
            ktfmt(catalog.findVersion("ktfmt").get().requiredVersion).kotlinlangStyle()
        }
    }
