plugins {
    id("catnap.jvm-conventions")
    id("catnap.testing")
}

dependencies { implementation(libs.jackson3) }

val frameworks =
    providers
        .gradleProperty("streamFrameworks")
        .getOrElse("mvc,webflux,micronaut,quarkus,ktor")
        .split(',')

require(
    frameworks.isNotEmpty() &&
        frameworks.distinct().size == frameworks.size &&
        frameworks.all { it in listOf("mvc", "webflux", "micronaut", "quarkus", "ktor") }
)

fun JavaExec.configureMeasurement(smoke: Boolean) {
    workingDir(rootProject.projectDir)
    group = "benchmark"
    description =
        if (smoke) "Checks native/projected streaming paths and measurement mechanics over HTTP."
        else
            "Measures native/projected NDJSON/SSE latency, throughput, allocation and retained memory."
    dependsOn(tasks.named("test"))
    dependsOn(frameworks.map { ":benchmarks:server-$it:benchmarkLaunchSpec" })
    classpath = sourceSets.main.get().runtimeClasspath
    mainClass.set("com.github.gregwhitaker.catnap.benchmarks.runner.StreamingMeasurements")
    javaLauncher.set(javaToolchains.launcherFor { languageVersion.set(JavaLanguageVersion.of(25)) })
    maxHeapSize = "512m"
    args(
        if (smoke) "smoke" else "measure",
        layout.buildDirectory
            .dir(if (smoke) "results/smoke" else "results/measure")
            .get()
            .asFile
            .absolutePath,
    )
    frameworks.forEach {
        args(
            it,
            project(":benchmarks:server-$it")
                .layout
                .buildDirectory
                .file("benchmark-launch.txt")
                .get()
                .asFile
                .absolutePath,
        )
    }
}

tasks.register<JavaExec>("smoke") { configureMeasurement(true) }

tasks.register<JavaExec>("measure") { configureMeasurement(false) }
