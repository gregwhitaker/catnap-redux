package com.github.gregwhitaker.catnap.examples.quarkus;

import static com.github.gregwhitaker.catnap.testkit.probe.FiniteResponseContract.*;
import static org.junit.jupiter.api.Assertions.*;

import io.quarkus.test.common.http.TestHTTPResource;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.junit.TestProfile;
import jakarta.inject.Inject;
import java.net.URI;
import java.util.List;
import org.junit.jupiter.api.Test;

@QuarkusTest
@TestProfile(FiniteResponseTest.Limits.class)
class FinitePublisherTest {
  @TestHTTPResource URI url;
  @Inject FinitePublisherResource resource;

  String base() {
    return url.toString().replaceAll("/$", "");
  }

  @Test
  void serializesConfiguredGenericValuesThenProjectsOneCompleteArray() throws Exception {
    var response = get(base(), "publisher" + query("fields", "payload(amount,internal,ignored)"));
    assertEquals(200, response.statusCode(), response.body());
    assertEquals(
        "[{\"payload\":{\"amount\":\"EUR:12.50\"}},{\"payload\":{\"amount\":\"EUR:12.50\"}}]",
        response.body());
    assertTrue(response.headers().firstValue("ETag").isEmpty());
    assertEquals("preserved", response.headers().firstValue("X-Application").orElseThrow());
    assertEquals("[]", get(base(), "publisher-empty?fields=id").body());
    assertEquals("[{},{}]", get(base(), "publisher?fields=missing").body());
    var nativeResponse = get(base(), "publisher");
    assertEquals(200, nativeResponse.statusCode(), nativeResponse.body());
    assertTrue(nativeResponse.body().contains("ACME"));
    assertFalse(nativeResponse.body().contains("internal"));
    assertEquals("\"original\"", nativeResponse.headers().firstValue("ETag").orElseThrow());
  }

  @Test
  void aTotalDocumentLimitCancelsBeforeTheOriginalBytesAreCommitted() throws Exception {
    var response = get(base(), "publisher-large?fields=id");
    assertEquals(500, response.statusCode(), response.body());
    assertFalse(response.body().contains("xxxxx"));
    assertTrue(resource.wasCancelled());
    assertTrue(resource.emittedCount() <= 5, "Overproduction: " + resource.emittedCount());
  }

  @Test
  void invalidQueriesAndServerFailuresUseTheCorrectStatus() throws Exception {
    assertEquals(400, get(base(), "publisher" + query("fields", "(")).statusCode());
    for (String path : List.of("publisher-error", "publisher-malformed")) {
      var response = get(base(), path + "?fields=id");
      assertEquals(500, response.statusCode(), response.body());
      assertFalse(response.body().contains("never leaked"));
    }
  }

  @Test
  void aDisconnectedClientCancelsAnIncompleteFiniteDocument() throws Exception {
    resource.resetWaiting();
    var response =
        java.net.http.HttpClient.newHttpClient()
            .sendAsync(
                java.net.http.HttpRequest.newBuilder(
                        URI.create(base() + "/catnap/publisher-wait?fields=id"))
                    .timeout(java.time.Duration.ofSeconds(10))
                    .GET()
                    .build(),
                java.net.http.HttpResponse.BodyHandlers.ofString());
    try {
      resource.waitingStarted().get(5, java.util.concurrent.TimeUnit.SECONDS);
      assertFalse(response.isDone(), "An incomplete finite array must not be committed");
      response.cancel(true);
      resource.waitingCancelled().get(5, java.util.concurrent.TimeUnit.SECONDS);
    } finally {
      response.cancel(true);
    }
  }
}
